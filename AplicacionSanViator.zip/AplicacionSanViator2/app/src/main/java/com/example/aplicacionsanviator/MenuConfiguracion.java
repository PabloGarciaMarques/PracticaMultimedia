package com.example.aplicacionsanviator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MenuConfiguracion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_configuracion);
    }
}