package com.example.aplicacionsanviator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PantallaPrincipalJefeEstudios extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_principal_jefe_estudios);
    }
}